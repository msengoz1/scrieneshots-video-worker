# Scrieneshots Video Worker
Render worker for Scrieneshots Content Board.

Render settings:
- Runtime: Python
- Build: `pip install -r requirements.txt`
- Start: `bash start.sh`

First deployment checks `/health` for FFmpeg and subtitle-filter support.
